import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Main {
    static class InvalidStayException extends Exception {
        private final int rejectedValue;
        InvalidStayException(String message) { super(message); rejectedValue = -1; }
        InvalidStayException(String message, Throwable cause) { super(message, cause); rejectedValue = -1; }
        InvalidStayException(int value, String message) { super(message); rejectedValue = value; }
        public int getRejectedValue() { return rejectedValue; }
    }
    static class InvalidChargeException extends Exception {
        InvalidChargeException(String message) { super(message); }
        InvalidChargeException(String message, Throwable cause) { super(message, cause); }
    }
    static class InvalidCoverageException extends Exception {
        InvalidCoverageException(String message) { super(message); }
        InvalidCoverageException(String message, Throwable cause) { super(message, cause); }
    }
    static class InvalidDiscountException extends RuntimeException {
        InvalidDiscountException(String message) { super(message); }
        InvalidDiscountException(String message, Throwable cause) { super(message, cause); }
    }
    static class InvalidRecordException extends Exception {
        InvalidRecordException(String message) { super(message); }
        InvalidRecordException(String message, Throwable cause) { super(message, cause); }
    }
    static class EmptyInputFileException extends Exception {
        EmptyInputFileException(String message) { super(message); }
        EmptyInputFileException(String message, Throwable cause) { super(message, cause); }
    }

    static class Patient {
        private String patientId;
        private String name;
        private int daysAdmitted;
        private double roomRatePerDay;
        private double medicineCharges;
        static String hospitalName = "City Multi-Speciality Hospital";
        static double registrationFee = 500.0;
        static int patientCount = 0;

        public Patient() throws InvalidStayException, InvalidChargeException {
            this("UNKNOWN", "Unknown", 1, 0, 0);
        }
        public Patient(String patientId, String name, int daysAdmitted)
                throws InvalidStayException, InvalidChargeException {
            this(patientId, name, daysAdmitted, 0, 0);
        }
        public Patient(String patientId, String name, int daysAdmitted,
                       double roomRatePerDay, double medicineCharges)
                throws InvalidStayException, InvalidChargeException {
            setPatientId(patientId);
            setName(name);
            setDaysAdmitted(daysAdmitted);
            setRoomRatePerDay(roomRatePerDay);
            setMedicineCharges(medicineCharges);
            patientCount++;
        }
        public String getPatientId() { return patientId; }
        public String getName() { return name; }
        public int getDaysAdmitted() { return daysAdmitted; }
        public double getRoomRatePerDay() { return roomRatePerDay; }
        public double getMedicineCharges() { return medicineCharges; }
        public void setPatientId(String v) {
            if (v == null || v.trim().isEmpty()) throw new IllegalArgumentException("Patient ID cannot be empty");
            patientId = v.trim();
        }
        public void setName(String v) {
            if (v == null || v.trim().isEmpty()) throw new IllegalArgumentException("Patient name cannot be empty");
            name = v.trim();
        }
        public void setDaysAdmitted(int v) throws InvalidStayException {
            if (v < 1) throw new InvalidStayException(v, "Days admitted must be at least 1");
            daysAdmitted = v;
        }
        public void setRoomRatePerDay(double v) throws InvalidChargeException {
            if (!Double.isFinite(v) || v < 0) throw new InvalidChargeException("Room rate cannot be negative");
            roomRatePerDay = v;
        }
        public void setMedicineCharges(double v) throws InvalidChargeException {
            if (!Double.isFinite(v) || v < 0) throw new InvalidChargeException("Medicine charges cannot be negative");
            medicineCharges = v;
        }
        public double calculateBill() {
            return daysAdmitted * roomRatePerDay + medicineCharges + registrationFee;
        }
        public double calculateBill(double discount) {
            if (!Double.isFinite(discount) || discount < 0 || discount > 100)
                throw new InvalidDiscountException("Discount must be between 0 and 100");
            return calculateBill() * (1.0 - discount / 100.0);
        }
        public String compareBill(Patient other) {
            return calculateBill() > other.calculateBill() ? name : other.name;
        }
        public void displayPatient(BufferedWriter bw) throws IOException {
            bw.write("Patient ID: " + patientId); bw.newLine();
            bw.write("Name: " + name); bw.newLine();
            bw.write("Days admitted: " + daysAdmitted); bw.newLine();
            bw.write("Room rate/day: Rs. " + money(roomRatePerDay)); bw.newLine();
            bw.write("Medicine charges: Rs. " + money(medicineCharges)); bw.newLine();
            bw.write("Base bill: Rs. " + money(daysAdmitted * roomRatePerDay + medicineCharges + registrationFee)); bw.newLine();
        }
    }

    static class InsuredPatient extends Patient {
        private String insuranceProvider;
        private double coveragePercent;
        private double coverageLimit;
        static int claimProcessingDays = 15;

        public InsuredPatient() throws InvalidStayException, InvalidChargeException, InvalidCoverageException {
            this("UNKNOWN", "Unknown", 1, 0, 0, "Unknown", 0, 0);
        }
        public InsuredPatient(String patientId, String name, int days, double roomRate, double medicine,
                              String provider, double coveragePercent, double coverageLimit)
                throws InvalidStayException, InvalidChargeException, InvalidCoverageException {
            super(patientId, name, days, roomRate, medicine);
            try {
                setInsuranceProvider(provider);
                setCoveragePercent(coveragePercent);
                setCoverageLimit(coverageLimit);
            } catch (InvalidCoverageException | IllegalArgumentException ex) {
                Patient.patientCount--; // A failed child construction must not count as a created object.
                throw ex;
            }
        }
        public String getInsuranceProvider() { return insuranceProvider; }
        public double getCoveragePercent() { return coveragePercent; }
        public double getCoverageLimit() { return coverageLimit; }
        public void setInsuranceProvider(String v) {
            if (v == null || v.trim().isEmpty()) throw new IllegalArgumentException("Insurance provider cannot be empty");
            insuranceProvider = v.trim();
        }
        public void setCoveragePercent(double v) throws InvalidCoverageException {
            if (!Double.isFinite(v) || v < 0 || v > 100)
                throw new InvalidCoverageException("Coverage percent must be between 0 and 100");
            coveragePercent = v;
        }
        public void setCoverageLimit(double v) throws InvalidCoverageException {
            if (!Double.isFinite(v) || v < 0)
                throw new InvalidCoverageException("Coverage limit cannot be negative");
            coverageLimit = v;
        }
        public double calculateInsuranceClaim() {
            return Math.min(super.calculateBill() * coveragePercent / 100.0, coverageLimit);
        }
        @Override public double calculateBill() {
            return super.calculateBill() - calculateInsuranceClaim();
        }
        @Override public void displayPatient(BufferedWriter bw) throws IOException {
            super.displayPatient(bw);
            bw.write("Insurance provider: " + insuranceProvider); bw.newLine();
            bw.write("Coverage percent: " + String.format(Locale.US, "%.2f", coveragePercent) + "%"); bw.newLine();
            bw.write("Insurance claim: Rs. " + money(calculateInsuranceClaim())); bw.newLine();
            bw.write("Final payable amount: Rs. " + money(calculateBill())); bw.newLine();
            bw.write("Claim processing days (display only): " + claimProcessingDays); bw.newLine();
        }
    }

    private static String money(double value) { return String.format(Locale.US, "%.2f", value); }

    private static File validateInputFile(String path) throws FileNotFoundException, EmptyInputFileException {
        File f = new File(path);
        if (!f.exists() || !f.isFile() || !f.canRead()) throw new FileNotFoundException("Input file is missing or cannot be read: " + path);
        if (f.length() == 0) throw new EmptyInputFileException("Input file is empty: " + path);
        return f;
    }

    private static String[] fields(String line) {
        String[] parts = line.split(",", -1);
        for (int i = 0; i < parts.length; i++) parts[i] = parts[i].trim();
        return parts;
    }

    private static void logError(BufferedWriter errorWriter, int lineNo, String record, Exception ex)
            throws IOException {
        errorWriter.write("Line " + lineNo + " | " + record + " | " +
                ex.getClass().getSimpleName() + " | " + ex.getMessage());
        errorWriter.newLine();
        errorWriter.flush();
    }

    private static String parseError(String line, RuntimeException cause) throws InvalidRecordException {
        throw new InvalidRecordException("Invalid record format or non-numeric value: " + line, cause);
    }

    public static String findHighestBill(Patient[] patients) {
        Patient best = null;
        for (Patient p : patients) {
            if (p != null && (best == null || p.calculateBill() > best.calculateBill())) best = p;
        }
        return best == null ? "No patients" : best.getName();
    }

    public static double secondHighestBill(Patient[] patients) {
        List<Double> bills = new ArrayList<>();
        for (Patient p : patients) if (p != null) bills.add(p.calculateBill());
        if (bills.size() < 2) return -1;
        bills.sort(Collections.reverseOrder());
        return bills.get(1);
    }

    public static void main(String[] args) {
        String inputPath = args.length > 0 ? args[0] : "input/patients.txt";
        File outputDir = new File("output");
        if (!outputDir.exists()) outputDir.mkdirs();
        File reportFile = new File(outputDir, "discharge_bills.txt");
        File errorFile = new File(outputDir, "errors.txt");

        int recordsRead = 0, accepted = 0, rejected = 0;
        List<Patient> acceptedPatients = new ArrayList<>();
        String firstLine;
        try {
            File inputFile = validateInputFile(inputPath);
            try (BufferedWriter errors = new BufferedWriter(new FileWriter(errorFile, true))) {
                errors.write("\\n=== Run: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + " ===");
                errors.newLine();
                try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
                    firstLine = br.readLine();
                    int n;
                    try {
                        if (firstLine == null || firstLine.trim().isEmpty()) throw new NumberFormatException("Missing record count");
                        n = Integer.parseInt(firstLine.trim());
                        if (n <= 0) throw new EmptyInputFileException("N is missing or zero");
                    } catch (NumberFormatException ex) {
                        throw new InvalidRecordException("First line must contain a positive record count", ex);
                    }
                    Patient[] patients = new Patient[n];
                    String line;
                    int lineNo = 1, slot = 0;
                    while ((line = br.readLine()) != null) {
                        lineNo++;
                        if (line.trim().isEmpty() || line.trim().startsWith("#")) continue;
                        try {
                            String[] f = fields(line);
                            Patient p;
                            if ("G".equalsIgnoreCase(f[0])) {
                                if (f.length != 7) throw new InvalidRecordException("General patient requires 7 fields");
                                p = new Patient(f[1], f[2], Integer.parseInt(f[3]),
                                        Double.parseDouble(f[4]), Double.parseDouble(f[5]));
                                double discount = Double.parseDouble(f[6]);
                                // Validate discount now; it is applied during report generation.
                                if (discount < 0 || discount > 100) throw new InvalidDiscountException("Discount must be between 0 and 100");
                                generalDiscounts.put(p.getPatientId(), discount);
                            } else if ("I".equalsIgnoreCase(f[0])) {
                                if (f.length != 9) throw new InvalidRecordException("Insured patient requires 9 fields");
                                p = new InsuredPatient(f[1], f[2], Integer.parseInt(f[3]),
                                        Double.parseDouble(f[4]), Double.parseDouble(f[5]), f[6],
                                        Double.parseDouble(f[7]), Double.parseDouble(f[8]));
                            } else {
                                throw new InvalidRecordException("Unknown patient type code: " + f[0]);
                            }
                            if (slot >= patients.length) throw new InvalidRecordException("More records than declared N");
                            patients[slot++] = p;
                            acceptedPatients.add(p);
                            accepted++;
                        } catch (InvalidStayException ex) {
                            rejected++; logError(errors, lineNo, line, ex);
                        } catch (InvalidChargeException ex) {
                            rejected++; logError(errors, lineNo, line, ex);
                        } catch (InvalidCoverageException ex) {
                            rejected++; logError(errors, lineNo, line, ex);
                        } catch (InvalidDiscountException ex) {
                            rejected++; logError(errors, lineNo, line, ex);
                        } catch (InvalidRecordException ex) {
                            rejected++; logError(errors, lineNo, line, ex);
                        } catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
                            rejected++; logError(errors, lineNo, line,
                                    new InvalidRecordException("Invalid record format or non-numeric value", ex));
                        } finally {
                            recordsRead++;
                        }
                    }

                    // Rebuild a correctly sized common parent array, preserving mixed parent/child objects.
                    Patient[] all = acceptedPatients.toArray(new Patient[0]);
                    try (BufferedWriter bw = new BufferedWriter(new FileWriter(reportFile))) {
                        bw.write("HOSPITAL PATIENT BILLING SYSTEM"); bw.newLine();
                        bw.write("Hospital: " + Patient.hospitalName); bw.newLine();
                        bw.write("=================================================="); bw.newLine();
                        for (Patient p : all) {
                            p.displayPatient(bw);
                            if (p instanceof InsuredPatient) {
                                bw.write("Bill (patient payable): Rs. " + money(p.calculateBill()));
                            } else {
                                double d = generalDiscounts.getOrDefault(p.getPatientId(), 0.0);
                                bw.write("Bill after discount (" + money(d) + "%): Rs. " + money(p.calculateBill(d)));
                            }
                            bw.newLine();
                            bw.write("--------------------------------------------------"); bw.newLine();
                        }
                        if (all.length >= 2) bw.write("compareBill() winner: " + all[0].compareBill(all[1]));
                        else bw.write("compareBill() winner: Not available (fewer than two patients)");
                        bw.newLine();
                        bw.write("Highest bill patient: " + findHighestBill(all)); bw.newLine();
                        bw.write("Second highest bill: Rs. " + money(secondHighestBill(all))); bw.newLine();
                        bw.write("Final patientCount: " + Patient.patientCount); bw.newLine();
                        bw.write("Records read: " + recordsRead + ", accepted: " + accepted + ", rejected: " + rejected); bw.newLine();
                        bw.flush();
                    }
                }
            }
            System.out.println("Processing complete. See output folder.");
        } catch (EmptyInputFileException | InvalidRecordException | IOException ex) {
            try (BufferedWriter errors = new BufferedWriter(new FileWriter(errorFile, true))) {
                errors.write("FATAL | " + ex.getClass().getSimpleName() + " | " + ex.getMessage());
                errors.newLine();
            } catch (IOException ignored) { /* no further recovery possible */ }
            System.out.println("Processing failed. Check output/errors.txt.");
        }
    }

    private static final Map<String, Double> generalDiscounts = new HashMap<>();
}
