# Team 11 – Hospital Patient Billing System (PS-11)

## Project structure
- `src/Main.java` – Java implementation (Patient, InsuredPatient, custom exceptions, parser, calculations and report generation).
- `input/patients.txt` – sample input from the problem statement.
- `output/discharge_bills.txt` – generated report after running.
- `output/errors.txt` – rejected records (appended on each run).

## Requirements
- JDK 8 or later.
- Run commands from the project root.

## Compile and run
```bash
javac -d out src/Main.java
java -cp out Main
```
Optional custom input path:
```bash
java -cp out Main input/patients.txt
```

## Implemented rules
- General patient bill = days × room rate + medicine charges + Rs. 500 registration fee.
- General patient discount is applied as a percentage to the complete bill.
- Insured claim = minimum of (base bill × coverage percentage) and coverage limit.
- Insured patient payable amount = base bill − insurance claim.
- `findHighestBill()` and `secondHighestBill()` use the amount payable / final bill returned by `calculateBill()`.
- Invalid stay, charge, coverage, discount and malformed records are rejected and logged.
- Uses `BufferedReader`/`FileReader`, `BufferedWriter`/`FileWriter`, parent-type array, inheritance, overriding, overloading, static counter and try-with-resources.

## Sample invalid records
The supplied sample deliberately demonstrates:
- P006 → `InvalidStayException`
- P007 → `InvalidChargeException`
- P008 → `InvalidCoverageException`

The project report and error log are regenerated/appended when you run the program.
